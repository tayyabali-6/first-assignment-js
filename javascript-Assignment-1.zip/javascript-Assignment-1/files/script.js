// document.getElementById('alert-name').onclick = function (){
//     alert('Tayyab ALI')
//     document.getElementById('statment').innerHTML = 'Name ( Tayyab ALI )'
// }
// document.getElementById('alert-num').onclick = function (){
//     alert('123')
//     document.getElementById('statment').innerHTML = 'number ( 123 )'
// }
// document.getElementById('veriabel').onclick = function (){
//     alert('Veriables 3 types')
//     document.getElementById('statment').innerHTML = 'let firstName = "Tayyab"; <br>var lastName = "Ali";<br>const userAge = 25; '
// }
// document.getElementById('camelcase').onclick = function (){
//     alert('camelcase')
//     document.getElementById('statment').innerHTML = 'CamelCase is a popular naming convention in JavaScript for variables. In this style, the first word starts with a lowercase letter, and each subsequent word begins with an uppercase letter.'
// }
// document.getElementById('sum2-num').onclick = function (){
//     alert('sum 2 numbers')
//     document.getElementById('statment').innerHTML = 'let num1 = 5;<br>let num2 = 7;<br> let sum = num1 + num2'
//     document.getElementById('output').innerHTML='13'
// }
// document.getElementById('substruct-num').onclick = function (){
//     alert('substruct 2 numbers')
//     document.getElementById('statment').innerHTML = 'let num1 = 10;<br>let num2 = 5;<br> let sum = num10 - num5'
//     document.getElementById('output').innerHTML='5'
// }
// document.getElementById('multiply-num').onclick = function (){
//     alert('multiply 2 numbers')
//     document.getElementById('statment').innerHTML = 'let num1 = 15;<br>let num2 = 5;<br> let sum = num15 * num5'
//     document.getElementById('output').innerHTML='75'
// }
// document.getElementById('divide-num ').onclick = function (){
//     alert('divide 2 numbers')
//     document.getElementById('statment').innerHTML = 'let num1 = 10;<br>let num2 = 5;<br> let sum = num15 * num5'
//     document.getElementById('output').innerHTML='2'
// }
// document.getElementById('caluclate').onclick = function (){
//     alert('caluclate some  numbers')
//     document.getElementById('statment').innerHTML = ' let result = (8 / 3) * 5 - 9 * (5 + 6);'
//     document.getElementById('output').innerHTML='The result is: -85.67'
// }

// document.getElementById('clear-st').onclick = function () {
//     document.getElementById('statment').innerHTML=''
// }
// document.getElementById('clear-output').onclick = function () {
//     document.getElementById('output').innerHTML=''
// }









// document.getElementById('alert-name').onclick = function () {
//     alert('My name')
//     document.getElementById('statment').innerHTML = 'Myname ( Tayyab Ali )'
// }

// document.getElementById('alert-num').onclick = function () {
//     alert('Alert number')
//     document.getElementById('statment').innerHTML = 'Alert number ( 123 )'
// }

// document.getElementById('veriabel').onclick = function () {
//     alert('Show Veriables ')
//     document.getElementById('statment').innerHTML = 'Three types Veriables <br> let <br> var <br> const'
// }

// document.getElementById('camelcase').onclick = function () {
//     alert('Show CamelCase Example')
//     document.getElementById('statment').innerHTML = 'CamelCase is a popular naming convention in JavaScript for variables. In this style, the first word starts with a lowercase letter, and each subsequent word begins with an uppercase letter.'
// }

// document.getElementById('sum2-num').onclick = function () {
//     alert('Sum2-number')
//     document.getElementById('statment').innerHTML = 'let num1 = 7 <br> let num2 = 9 <br> let sum = num1 + num2 '
//     document.getElementById('output').innerHTML = '16'
// }

// document.getElementById('substruct-num').onclick = function () {
//     alert('Substruct-number')
//     document.getElementById('statment').innerHTML = 'let num1 = 7 <br> let num2 = 9 <br> let sum = num1 - num2 '
//     document.getElementById('output').innerHTML = '2'
// }

// document.getElementById('multiply-num').onclick = function () {
//     alert('Multiply-number')
//     document.getElementById('statment').innerHTML = 'let num1 = 7 <br> let num2 = 5 <br> let sum = num1 * num2 '
//     document.getElementById('output').innerHTML = '35'
// }

// document.getElementById('divide').onclick = function () {
//     alert('Divide-number')
//     document.getElementById('statment').innerHTML = 'let num1 = 30 <br> let num2 = 10 <br> let sum = num1 / num2 '
//     document.getElementById('output').innerHTML = '3'
// }

// document.getElementById('caluclate').onclick = function (){
//         alert('caluclate some  numbers')
//         document.getElementById('statment').innerHTML = ' let result = (8 / 3) * 5 - 9 * (5 + 6);'
//         document.getElementById('output').innerHTML='The result is: -85.67'
//     }
    
//     document.getElementById('clear-st').onclick = function () {
//         document.getElementById('statment').innerHTML=''
//     }
//     document.getElementById('clear-output').onclick = function () {
//         document.getElementById('output').innerHTML=''
//     }
    


document.getElementById('alert-name').addEventListener('click',function(){
    alert('My Name("Tayyab Ali")')
    document.getElementById('output').innerHTML='My Name("Tayyab Ali")'
})

document.getElementById('alert-num').addEventListener('click',function(){
    alert('alert num(123)')
    document.getElementById('output').innerHTML='alert num(123)'
})

document.getElementById('veriabel').addEventListener('click',function(){
    alert('Show veriable names')
    document.getElementById('output').innerHTML='let <br> var <br> const'
})

document.getElementById('camelcase').addEventListener('click',function(){
    alert('Show veriable names')
    document.getElementById('statment').innerHTML='CamelCase ek writing style hai jisme words ko jod kar likha jata hai, lekin har word ka pehla letter capital hota hai, except for the first word. Ye style programming aur naming conventions mein bohot use hoti hai.'
    document.getElementById('output').innerHTML=' Example: <br> camelCaseExample <br> myVariableName <br> calculateTotalAmount'
})

document.getElementById('sum2-num').addEventListener('click',function(){
    alert('Sum 2 Numbers')
    document.getElementById('statment').innerHTML='let sum1 = 3 <br> let sum2 = 5 <br> let sum3 = sum1 + sum2 <br> ?'
    document.getElementById('output').innerHTML='Ans = 8'
})

document.getElementById('substruct-num').addEventListener('click',function(){
    alert('substruct 2 Numbers')
    document.getElementById('statment').innerHTML='let sum1 = 3 <br> let sum2 = 5 <br> let sum3 = sum1 - sum2 <br> ?'
    document.getElementById('output').innerHTML='Ans = 2'
})

document.getElementById('multiply-num').addEventListener('click',function(){
    alert('multiply-num')
    document.getElementById('statment').innerHTML='let sum1 = 3 <br> let sum2 = 5 <br> let sum3 = sum1 * sum2 <br> ?'
    document.getElementById('output').innerHTML='Ans = 15'
})

document.getElementById('divide').addEventListener('click',function(){
    alert('divide-num')
    document.getElementById('statment').innerHTML='let sum1 = 25 <br> let sum2 = 5 <br> let sum3 = sum1 / sum2 <br> ?'
    document.getElementById('output').innerHTML='Ans = 5'
})

document.getElementById('caluclate').addEventListener('click',function(){
    alert('caluclate-num')
    document.getElementById('statment').innerHTML = ' let result = (8 / 3) * 5 - 9 * (5 + 6);'
        document.getElementById('output').innerHTML='The result is: -85.67'
})